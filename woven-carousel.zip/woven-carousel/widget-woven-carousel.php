<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit;

class Woven_Carousel_Widget extends Widget_Base {

    public function get_name() {
        return 'woven_carousel';
    }

    public function get_title() {
        return __( 'Woven Carousel', 'woven-carousel' );
    }

    public function get_icon() {
        return 'eicon-slider-full-screen';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    public function get_style_depends() {
        return [ 'woven-carousel-style' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Carousel Slides', 'woven-carousel' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'main_image',
            [
                'label' => __( 'Main Image', 'woven-carousel' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
            ]
        );

        $repeater->add_control(
            'heading',
            [
                'label' => __( 'Heading', 'woven-carousel' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Woven Wonders',
            ]
        );

        $repeater->add_control(
            'thumb1',
            [
                'label' => __( 'Thumbnail 1', 'woven-carousel' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $repeater->add_control(
            'thumb2',
            [
                'label' => __( 'Thumbnail 2', 'woven-carousel' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $repeater->add_control(
            'thumb3',
            [
                'label' => __( 'Thumbnail 3', 'woven-carousel' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'slides',
            [
                'label' => __( 'Slides', 'woven-carousel' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
                'title_field' => '{{{ heading }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( empty( $settings['slides'] ) ) return;

        echo '<div class="only-for-space-woven"><div class="woven-slider-wrapper"><div class="woven-slider-container">';

        foreach ( $settings['slides'] as $slide ) {
            ?>
            <div class="woven-slide">
                <div class="woven-main-image">
                    <img src="<?php echo esc_url( $slide['main_image']['url'] ); ?>" alt="Main Image" />
                    <div class="woven-main-text">
                        <h2><?php echo esc_html( $slide['heading'] ); ?></h2>
                    </div>
                    <div class="woven-overlay-images">
                        <?php foreach (['thumb1', 'thumb2', 'thumb3'] as $key): ?>
                            <?php if ( ! empty($slide[$key]['url']) ): ?>
                                <div class="overlay-thumb">
                                    <img src="<?php echo esc_url( $slide[$key]['url'] ); ?>" alt="Thumb" />
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php
        }

        echo '</div></div></div>';
    }
}
