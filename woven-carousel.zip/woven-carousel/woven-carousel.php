<?php
/**
 * Plugin Name: Woven Carousel
 * Plugin URI: https://github.com/rohitindustry09/woven-carousel
 * Description: A custom Elementor widget for a horizontally scrolling woven-style carousel.
 * Version: 1.0.0
 * Author: Rohit
 * Author URI: https://github.com/rohitindustry09
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: woven-carousel
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define('WOVEN_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Load Elementor widget
function woven_register_widget( $widgets_manager ) {
    require_once( WOVEN_PLUGIN_DIR . 'widget-woven-carousel.php' );
    $widgets_manager->register( new \Woven_Carousel_Widget() );
}
add_action( 'elementor/widgets/register', 'woven_register_widget' );

// Register and enqueue style
add_action('wp_enqueue_scripts', function () {
    wp_register_style(
        'woven-carousel-style',
        plugin_dir_url(__FILE__) . 'assets/css/woven-carousel.css',
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'assets/css/woven-carousel.css')
    );
});
