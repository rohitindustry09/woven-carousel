=== Woven Carousel ===
Contributors: rohit
Tags: elementor, carousel, image slider, horizontal scroll, image showcase
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight Elementor widget for luxury-style horizontal image carousels with overlapping images.

== Description ==

**Woven Carousel** is a stylish, fully responsive Elementor widget plugin inspired by luxury brand image carousels. Designed to create impactful visual sections with minimal effort.

**Features:**
- Main large background image
- Three front overlapping images with labels and links
- Horizontal scroll on mobile
- Custom padding, image size, and spacing
- Elementor widget integration
- Works with any theme

Ideal for product showcases like jewelry, fashion editorials, or storytelling banners.

== Installation ==

1. Upload the plugin ZIP via `Plugins → Add New → Upload Plugin`.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. In Elementor, search for **"Woven Carousel"** under the widget panel.
4. Drag it into any section and customize your content and images.

== Frequently Asked Questions ==

= Does this require Elementor? =  
Yes, this plugin adds a custom widget that only works inside Elementor.

= Can I use dynamic image fields? =  
Currently, you must manually select the main and thumbnail images via the widget controls.

= Is it responsive? =  
Yes. The carousel supports horizontal scrolling on mobile devices and adjusts spacing for smaller screens.

== Screenshots ==

1. Desktop layout with one large image and three overlapping thumbnails
2. Mobile horizontal scroll example
3. Elementor widget configuration panel

== Changelog ==

= 1.0.0 =
* Initial release
* Added Elementor widget with custom controls
* Responsive layout and horizontal scroll on mobile

== Upgrade Notice ==

= 1.0.0 =
First stable version

== License ==

This plugin is licensed under the GPLv2 or later.
